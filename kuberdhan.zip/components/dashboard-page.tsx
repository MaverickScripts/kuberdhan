"use client"

import { useEffect, useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { getPortfolio, getCoins, type Coin } from "@/lib/api"
import { motion } from "framer-motion"
import { ArrowUpRight, ArrowDownRight, TrendingUp, Wallet, DollarSign, PieChart, Eye, Plus } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import {
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts"

export function DashboardPage() {
  const [loading, setLoading] = useState(true)
  const [portfolio, setPortfolio] = useState<any>(null)
  const [trendingCoins, setTrendingCoins] = useState<Coin[]>([])
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const portfolioData = await getPortfolio()
        const coinsData = await getCoins()

        setPortfolio(portfolioData)
        setTrendingCoins(coinsData.slice(0, 5))
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch portfolio data. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 py-6">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6">
            <div className="flex flex-col gap-2">
              <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
              <p className="text-muted-foreground">Track your crypto portfolio and market trends</p>
            </div>

            {loading ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                {Array(4)
                  .fill(0)
                  .map((_, i) => (
                    <Card key={i}>
                      <CardHeader className="pb-2">
                        <Skeleton className="h-4 w-1/2" />
                        <Skeleton className="h-8 w-3/4" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-4 w-full" />
                      </CardContent>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>
                        <div className="flex items-center">
                          <Wallet className="mr-2 h-4 w-4" />
                          Total Portfolio Value
                        </div>
                      </CardDescription>
                      <CardTitle className="text-2xl">{formatCurrency(portfolio.total_value)}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center">
                        {portfolio.daily_change >= 0 ? (
                          <ArrowUpRight className="mr-2 h-4 w-4 text-green-500" />
                        ) : (
                          <ArrowDownRight className="mr-2 h-4 w-4 text-red-500" />
                        )}
                        <span className={portfolio.daily_change >= 0 ? "text-green-500" : "text-red-500"}>
                          {formatPercentage(portfolio.daily_change_percentage)} (24h)
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.1 }}
                >
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>
                        <div className="flex items-center">
                          <DollarSign className="mr-2 h-4 w-4" />
                          Total Profit/Loss
                        </div>
                      </CardDescription>
                      <CardTitle className="text-2xl">{formatCurrency(portfolio.total_profit_loss)}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center">
                        {portfolio.total_profit_loss >= 0 ? (
                          <ArrowUpRight className="mr-2 h-4 w-4 text-green-500" />
                        ) : (
                          <ArrowDownRight className="mr-2 h-4 w-4 text-red-500" />
                        )}
                        <span className={portfolio.total_profit_loss >= 0 ? "text-green-500" : "text-red-500"}>
                          {formatPercentage(portfolio.total_profit_loss_percentage)} (All time)
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.2 }}
                >
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>
                        <div className="flex items-center">
                          <PieChart className="mr-2 h-4 w-4" />
                          Portfolio Allocation
                        </div>
                      </CardDescription>
                      <CardTitle className="text-2xl">{portfolio.coins.length} Assets</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center">
                        <span className="text-muted-foreground">
                          {portfolio.coins[0].coin.name}:{" "}
                          {((portfolio.coins[0].value / portfolio.total_value) * 100).toFixed(2)}%
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.3 }}
                >
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>
                        <div className="flex items-center">
                          <Eye className="mr-2 h-4 w-4" />
                          Watchlist
                        </div>
                      </CardDescription>
                      <CardTitle className="text-2xl">5 Coins</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center">
                        <span className="text-muted-foreground">
                          {trendingCoins[0].name}: {formatPercentage(trendingCoins[0].price_change_percentage_24h)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            )}

            <Tabs defaultValue="portfolio" className="w-full">
              <TabsList className="grid w-full grid-cols-3 md:w-auto">
                <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
                <TabsTrigger value="trending">Trending</TabsTrigger>
              </TabsList>

              <TabsContent value="portfolio" className="space-y-4">
                <div className="grid gap-6 md:grid-cols-2">
                  <Card className="md:col-span-1">
                    <CardHeader>
                      <CardTitle>Portfolio Allocation</CardTitle>
                      <CardDescription>Distribution of your assets</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {loading ? (
                        <div className="flex justify-center items-center h-[300px]">
                          <Skeleton className="h-[300px] w-[300px] rounded-full" />
                        </div>
                      ) : (
                        <div className="h-[300px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <RePieChart>
                              <Pie
                                data={portfolio.coins.map((item: any) => ({
                                  name: item.coin.name,
                                  value: item.value,
                                }))}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={100}
                                fill="#8884d8"
                                dataKey="value"
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                              >
                                {portfolio.coins.map((_: any, index: number) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                            </RePieChart>
                          </ResponsiveContainer>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="md:col-span-1">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <div>
                        <CardTitle>Your Assets</CardTitle>
                        <CardDescription>All cryptocurrencies in your portfolio</CardDescription>
                      </div>
                      <Button size="sm">
                        <Plus className="mr-2 h-4 w-4" />
                        Add Asset
                      </Button>
                    </CardHeader>
                    <CardContent>
                      {loading ? (
                        <div className="space-y-4">
                          {Array(3)
                            .fill(0)
                            .map((_, i) => (
                              <div key={i} className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                  <Skeleton className="h-10 w-10 rounded-full" />
                                  <div className="space-y-2">
                                    <Skeleton className="h-4 w-20" />
                                    <Skeleton className="h-4 w-10" />
                                  </div>
                                </div>
                                <div className="text-right space-y-2">
                                  <Skeleton className="h-4 w-20 ml-auto" />
                                  <Skeleton className="h-4 w-10 ml-auto" />
                                </div>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {portfolio.coins.map((item: any, index: number) => (
                            <motion.div
                              key={item.coin.id}
                              className="flex items-center justify-between hover:bg-muted/50 p-2 rounded-lg cursor-pointer"
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ duration: 0.2, delay: index * 0.1 }}
                              whileHover={{ scale: 1.02 }}
                            >
                              <div className="flex items-center gap-4">
                                <img
                                  src={item.coin.image || "/placeholder.svg"}
                                  alt={item.coin.name}
                                  className="h-10 w-10 rounded-full"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=40&width=40"
                                  }}
                                />
                                <div>
                                  <div className="font-medium">{item.coin.name}</div>
                                  <div className="text-sm text-muted-foreground">{item.coin.symbol.toUpperCase()}</div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-medium">{formatCurrency(item.value)}</div>
                                <div
                                  className={`text-sm ${item.coin.price_change_percentage_24h >= 0 ? "text-green-500" : "text-red-500"}`}
                                >
                                  {formatPercentage(item.coin.price_change_percentage_24h)}
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="performance" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Portfolio Performance</CardTitle>
                    <CardDescription>Track your portfolio's performance over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : (
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={[
                              { date: "Apr 24", value: portfolio.total_value - 1200 },
                              { date: "Apr 25", value: portfolio.total_value - 800 },
                              { date: "Apr 26", value: portfolio.total_value - 1500 },
                              { date: "Apr 27", value: portfolio.total_value - 1000 },
                              { date: "Apr 28", value: portfolio.total_value - 500 },
                              { date: "Apr 29", value: portfolio.total_value - 200 },
                              { date: "Apr 30", value: portfolio.total_value },
                            ]}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis
                              tickFormatter={(value) => `$${(value / 1000).toFixed(1)}k`}
                              domain={["auto", "auto"]}
                            />
                            <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                            <Line
                              type="monotone"
                              dataKey="value"
                              stroke="hsl(var(--primary))"
                              strokeWidth={2}
                              dot={{ r: 4 }}
                              activeDot={{ r: 8 }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="trending" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Trending Coins</CardTitle>
                      <CardDescription>Most popular cryptocurrencies right now</CardDescription>
                    </div>
                    <Button variant="outline" size="sm">
                      <TrendingUp className="mr-2 h-4 w-4" />
                      View All
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <div className="space-y-4">
                        {Array(5)
                          .fill(0)
                          .map((_, i) => (
                            <div key={i} className="flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                <Skeleton className="h-10 w-10 rounded-full" />
                                <div className="space-y-2">
                                  <Skeleton className="h-4 w-20" />
                                  <Skeleton className="h-4 w-10" />
                                </div>
                              </div>
                              <div className="text-right space-y-2">
                                <Skeleton className="h-4 w-20 ml-auto" />
                                <Skeleton className="h-4 w-10 ml-auto" />
                              </div>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {trendingCoins.map((coin, index) => (
                          <motion.div
                            key={coin.id}
                            className="flex items-center justify-between hover:bg-muted/50 p-2 rounded-lg cursor-pointer"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.2, delay: index * 0.1 }}
                            whileHover={{ scale: 1.02 }}
                          >
                            <div className="flex items-center gap-4">
                              <div className="flex items-center justify-center h-10 w-10 rounded-full bg-primary/10">
                                {index + 1}
                              </div>
                              <div>
                                <div className="font-medium">{coin.name}</div>
                                <div className="text-sm text-muted-foreground">{coin.symbol.toUpperCase()}</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">{formatCurrency(coin.current_price)}</div>
                              <div
                                className={`text-sm ${coin.price_change_percentage_24h >= 0 ? "text-green-500" : "text-red-500"}`}
                              >
                                {formatPercentage(coin.price_change_percentage_24h)}
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
