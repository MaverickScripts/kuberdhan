"use client"

import { useEffect, useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Progress } from "@/components/ui/progress"
import { getAchievements, type Achievement } from "@/lib/api"
import { motion } from "framer-motion"
import { Award, Lock, Share2, Trophy } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export function AchievementsPage() {
  const [loading, setLoading] = useState(true)
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const achievementsData = await getAchievements()
        setAchievements(achievementsData)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch achievements data. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  const formatDate = (dateString?: string) => {
    if (!dateString) return "Not unlocked yet"
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(date)
  }

  const calculateProgress = () => {
    const total = achievements.length
    const unlocked = achievements.filter((achievement) => achievement.unlocked).length
    return Math.round((unlocked / total) * 100)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 py-6">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6">
            <div className="flex flex-col gap-2">
              <h1 className="text-3xl font-bold tracking-tight">Achievements</h1>
              <p className="text-muted-foreground">Track your progress and earn rewards</p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              {loading ? (
                <>
                  <Skeleton className="h-32" />
                  <Skeleton className="h-32" />
                  <Skeleton className="h-32" />
                </>
              ) : (
                <>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="h-full">
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <Trophy className="mr-2 h-4 w-4" />
                            Total Achievements
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">{achievements.length}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <span className="text-muted-foreground">
                            {achievements.filter((a) => a.unlocked).length} unlocked
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 }}
                  >
                    <Card className="h-full">
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <Award className="mr-2 h-4 w-4" />
                            Progress
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">{calculateProgress()}%</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <Progress value={calculateProgress()} className="h-2" />
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.2 }}
                  >
                    <Card className="h-full">
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <Share2 className="mr-2 h-4 w-4" />
                            Leaderboard Rank
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">#42</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <span className="text-muted-foreground">Top 10% of users</span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </>
              )}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Your Achievements</CardTitle>
                <CardDescription>Unlock achievements by using the app and trading</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {loading
                    ? Array(6)
                        .fill(0)
                        .map((_, i) => <Skeleton key={i} className="h-40" />)
                    : achievements.map((achievement, index) => (
                        <motion.div
                          key={achievement.id}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="hover-float"
                        >
                          <Card
                            className={`h-full overflow-hidden ${
                              achievement.unlocked ? "border-primary/50" : "opacity-70"
                            }`}
                          >
                            <CardHeader className="pb-2">
                              <div className="flex justify-between items-center">
                                <div
                                  className={`flex items-center justify-center h-12 w-12 rounded-full text-2xl ${
                                    achievement.unlocked ? "bg-primary/20" : "bg-muted"
                                  }`}
                                >
                                  {achievement.unlocked ? (
                                    achievement.icon
                                  ) : (
                                    <Lock className="h-6 w-6 text-muted-foreground" />
                                  )}
                                </div>
                                {achievement.unlocked && (
                                  <div className="text-xs text-muted-foreground">
                                    Unlocked: {formatDate(achievement.unlocked_at)}
                                  </div>
                                )}
                              </div>
                              <CardTitle className="text-lg mt-2">{achievement.title}</CardTitle>
                              <CardDescription>{achievement.description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                              {!achievement.unlocked && achievement.progress !== undefined && (
                                <div className="space-y-1">
                                  <div className="flex justify-between text-xs">
                                    <span>Progress</span>
                                    <span>
                                      {achievement.progress} / {achievement.max_progress}
                                    </span>
                                  </div>
                                  <Progress
                                    value={(achievement.progress / (achievement.max_progress || 1)) * 100}
                                    className="h-2"
                                  />
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upcoming Achievements</CardTitle>
                <CardDescription>Challenges to work towards</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      title: "Trading Master",
                      description: "Complete 100 trades",
                      icon: "🎯",
                      progress: 23,
                      maxProgress: 100,
                    },
                    {
                      title: "Crypto Millionaire",
                      description: "Reach a portfolio value of $1,000,000",
                      icon: "💰",
                      progress: 42345.67,
                      maxProgress: 1000000,
                    },
                    {
                      title: "Market Guru",
                      description: "Predict market direction correctly 10 times in a row",
                      icon: "🔮",
                      progress: 3,
                      maxProgress: 10,
                    },
                    {
                      title: "Social Butterfly",
                      description: "Share your portfolio 25 times",
                      icon: "🦋",
                      progress: 5,
                      maxProgress: 25,
                    },
                  ].map((achievement, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      className="flex items-center gap-4 p-4 rounded-lg border"
                    >
                      <div className="flex items-center justify-center h-12 w-12 rounded-full bg-muted text-2xl">
                        {achievement.icon}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{achievement.title}</h4>
                        <p className="text-sm text-muted-foreground">{achievement.description}</p>
                        <div className="mt-2 space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Progress</span>
                            <span>
                              {achievement.progress.toLocaleString()} / {achievement.maxProgress.toLocaleString()}
                            </span>
                          </div>
                          <Progress value={(achievement.progress / achievement.maxProgress) * 100} className="h-2" />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
