"use client"

import { useEffect, useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { getCoins, type Coin } from "@/lib/api"
import { motion } from "framer-motion"
import {
  ArrowUpRight,
  ArrowDownRight,
  Search,
  Star,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Filter,
  Plus,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export function MarketPage() {
  const [loading, setLoading] = useState(true)
  const [coins, setCoins] = useState<Coin[]>([])
  const [filteredCoins, setFilteredCoins] = useState<Coin[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const coinsData = await getCoins()
        setCoins(coinsData)
        setFilteredCoins(coinsData)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch market data. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredCoins(coins)
    } else {
      const filtered = coins.filter(
        (coin) =>
          coin.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          coin.symbol.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setFilteredCoins(filtered)
    }
  }, [searchQuery, coins])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`
  }

  const formatMarketCap = (value: number) => {
    if (value >= 1_000_000_000_000) {
      return `$${(value / 1_000_000_000_000).toFixed(2)}T`
    }
    if (value >= 1_000_000_000) {
      return `$${(value / 1_000_000_000).toFixed(2)}B`
    }
    if (value >= 1_000_000) {
      return `$${(value / 1_000_000).toFixed(2)}M`
    }
    return formatCurrency(value)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 py-6">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6">
            <div className="flex flex-col gap-2">
              <h1 className="text-3xl font-bold tracking-tight">Market</h1>
              <p className="text-muted-foreground">Track cryptocurrency prices and market trends</p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {loading ? (
                Array(4)
                  .fill(0)
                  .map((_, i) => (
                    <Card key={i}>
                      <CardHeader className="pb-2">
                        <Skeleton className="h-4 w-1/2" />
                        <Skeleton className="h-8 w-3/4" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-4 w-full" />
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <DollarSign className="mr-2 h-4 w-4" />
                            Market Cap
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">
                          {formatMarketCap(coins.reduce((acc, coin) => acc + coin.market_cap, 0))}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <ArrowUpRight className="mr-2 h-4 w-4 text-green-500" />
                          <span className="text-green-500">+2.34% (24h)</span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <TrendingUp className="mr-2 h-4 w-4" />
                            Top Gainer (24h)
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">
                          {
                            coins.reduce(
                              (max, coin) =>
                                coin.price_change_percentage_24h > max.price_change_percentage_24h ? coin : max,
                              coins[0],
                            ).name
                          }
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <ArrowUpRight className="mr-2 h-4 w-4 text-green-500" />
                          <span className="text-green-500">
                            {formatPercentage(
                              coins.reduce(
                                (max, coin) =>
                                  coin.price_change_percentage_24h > max.price_change_percentage_24h ? coin : max,
                                coins[0],
                              ).price_change_percentage_24h,
                            )}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.2 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <TrendingDown className="mr-2 h-4 w-4" />
                            Top Loser (24h)
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">
                          {
                            coins.reduce(
                              (min, coin) =>
                                coin.price_change_percentage_24h < min.price_change_percentage_24h ? coin : min,
                              coins[0],
                            ).name
                          }
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <ArrowDownRight className="mr-2 h-4 w-4 text-red-500" />
                          <span className="text-red-500">
                            {formatPercentage(
                              coins.reduce(
                                (min, coin) =>
                                  coin.price_change_percentage_24h < min.price_change_percentage_24h ? coin : min,
                                coins[0],
                              ).price_change_percentage_24h,
                            )}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.3 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <Star className="mr-2 h-4 w-4" />
                            Watchlist
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">5 Coins</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <Button variant="outline" size="sm" className="text-xs">
                            <Plus className="mr-1 h-3 w-3" />
                            Add to Watchlist
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </>
              )}
            </div>

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex w-full max-w-sm items-center space-x-2">
                <Input
                  type="search"
                  placeholder="Search coins..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
                <Button type="submit" size="icon" variant="ghost">
                  <Search className="h-4 w-4" />
                  <span className="sr-only">Search</span>
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
            </div>

            <Tabs defaultValue="all" className="w-full">
              <TabsList className="grid w-full grid-cols-4 md:w-auto">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="defi">DeFi</TabsTrigger>
                <TabsTrigger value="nft">NFT</TabsTrigger>
                <TabsTrigger value="meme">Meme</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>All Cryptocurrencies</CardTitle>
                    <CardDescription>Prices and market data for all cryptocurrencies</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <div className="grid grid-cols-5 gap-4 p-4 font-medium">
                        <div>Name</div>
                        <div className="text-right">Price</div>
                        <div className="text-right">24h %</div>
                        <div className="text-right hidden md:block">Market Cap</div>
                        <div className="text-right hidden md:block">Volume (24h)</div>
                      </div>
                      {loading ? (
                        <div className="divide-y">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <div key={i} className="grid grid-cols-5 gap-4 p-4">
                                <div className="flex items-center gap-4">
                                  <Skeleton className="h-10 w-10 rounded-full" />
                                  <div className="space-y-2">
                                    <Skeleton className="h-4 w-20" />
                                    <Skeleton className="h-4 w-10" />
                                  </div>
                                </div>
                                <div className="text-right">
                                  <Skeleton className="h-4 w-20 ml-auto" />
                                </div>
                                <div className="text-right">
                                  <Skeleton className="h-4 w-16 ml-auto" />
                                </div>
                                <div className="text-right hidden md:block">
                                  <Skeleton className="h-4 w-24 ml-auto" />
                                </div>
                                <div className="text-right hidden md:block">
                                  <Skeleton className="h-4 w-24 ml-auto" />
                                </div>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <div className="divide-y">
                          {filteredCoins.map((coin, index) => (
                            <motion.div
                              key={coin.id}
                              className="grid grid-cols-5 gap-4 p-4 hover:bg-muted/50 cursor-pointer"
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              transition={{ duration: 0.3, delay: index * 0.05 }}
                              whileHover={{ backgroundColor: "rgba(0,0,0,0.05)" }}
                            >
                              <div className="flex items-center gap-4">
                                <img
                                  src={coin.image || "/placeholder.svg"}
                                  alt={coin.name}
                                  className="h-10 w-10 rounded-full"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=40&width=40"
                                  }}
                                />
                                <div>
                                  <div className="font-medium">{coin.name}</div>
                                  <div className="text-sm text-muted-foreground">{coin.symbol.toUpperCase()}</div>
                                </div>
                              </div>
                              <div className="text-right self-center font-medium">
                                {formatCurrency(coin.current_price)}
                              </div>
                              <div className="text-right self-center">
                                <Badge variant={coin.price_change_percentage_24h >= 0 ? "default" : "destructive"}>
                                  {formatPercentage(coin.price_change_percentage_24h)}
                                </Badge>
                              </div>
                              <div className="text-right self-center hidden md:block">
                                {formatMarketCap(coin.market_cap)}
                              </div>
                              <div className="text-right self-center hidden md:block">
                                {formatCurrency(coin.total_volume)}
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="defi" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>DeFi Tokens</CardTitle>
                    <CardDescription>Decentralized Finance tokens and protocols</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-center p-8">
                      <div className="text-center">
                        <h3 className="text-lg font-medium">DeFi Category</h3>
                        <p className="text-muted-foreground">Showing tokens related to decentralized finance</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="nft" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>NFT Tokens</CardTitle>
                    <CardDescription>Non-Fungible Token related cryptocurrencies</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-center p-8">
                      <div className="text-center">
                        <h3 className="text-lg font-medium">NFT Category</h3>
                        <p className="text-muted-foreground">Showing tokens related to NFTs and digital collectibles</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="meme" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Meme Coins</CardTitle>
                    <CardDescription>Popular meme-based cryptocurrencies</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-center p-8">
                      <div className="text-center">
                        <h3 className="text-lg font-medium">Meme Coin Category</h3>
                        <p className="text-muted-foreground">Showing popular meme coins and community tokens</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
