"use client"

import { useEffect, useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getAlerts, getCoins, type Alert, type Coin } from "@/lib/api"
import { motion } from "framer-motion"
import { Bell, Plus, Trash2, BellOff, BellRing, Newspaper, TrendingUp } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export function AlertsPage() {
  const [loading, setLoading] = useState(true)
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [coins, setCoins] = useState<Coin[]>([])
  const [selectedCoin, setSelectedCoin] = useState<string>("")
  const [alertType, setAlertType] = useState<"price" | "news" | "trend">("price")
  const [condition, setCondition] = useState<"above" | "below">("above")
  const [threshold, setThreshold] = useState<string>("")
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const [alertsData, coinsData] = await Promise.all([getAlerts(), getCoins()])
        setAlerts(alertsData)
        setCoins(coinsData)
        if (coinsData.length > 0) {
          setSelectedCoin(coinsData[0].id)
        }
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch alerts data. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  const handleCreateAlert = () => {
    if (alertType === "price" && (!selectedCoin || !threshold || isNaN(Number(threshold)) || Number(threshold) <= 0)) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Please enter a valid price threshold.",
      })
      return
    }

    const coin = coins.find((c) => c.id === selectedCoin)
    if (alertType === "price" && !coin) return

    let message = ""
    if (alertType === "price") {
      message = `${coin?.name} price is ${condition} $${threshold}`
    } else if (alertType === "news") {
      message = `Breaking news about ${coin?.name || "crypto market"}`
    } else {
      message = `${coin?.name || "Crypto market"} is trending on social media`
    }

    const newAlert: Alert = {
      id: `alert_${Math.random().toString(36).substr(2, 9)}`,
      type: alertType,
      coin: selectedCoin,
      condition: alertType === "price" ? condition : undefined,
      threshold: alertType === "price" ? Number(threshold) : undefined,
      message,
      created_at: new Date().toISOString(),
      triggered: false,
    }

    setAlerts([newAlert, ...alerts])
    setThreshold("")

    toast({
      title: "Alert created",
      description: "You will be notified when the conditions are met.",
    })
  }

  const handleDeleteAlert = (id: string) => {
    setAlerts(alerts.filter((alert) => alert.id !== id))
    toast({
      title: "Alert deleted",
      description: "The alert has been removed from your list.",
    })
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    }).format(date)
  }

  const alertTypeIcon = (type: string) => {
    switch (type) {
      case "price":
        return <Bell className="h-4 w-4" />
      case "news":
        return <Newspaper className="h-4 w-4" />
      case "trend":
        return <TrendingUp className="h-4 w-4" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 py-6">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6">
            <div className="flex flex-col gap-2">
              <h1 className="text-3xl font-bold tracking-tight">Alerts</h1>
              <p className="text-muted-foreground">Set up notifications for price movements, news, and market trends</p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Create Alert</CardTitle>
                  <CardDescription>Set up a new alert for price, news, or trends</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="alert-type">Alert Type</Label>
                      <Select
                        value={alertType}
                        onValueChange={(value) => setAlertType(value as "price" | "news" | "trend")}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select alert type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="price">Price Alert</SelectItem>
                          <SelectItem value="news">News Alert</SelectItem>
                          <SelectItem value="trend">Trend Alert</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="coin">Select Coin</Label>
                      <Select value={selectedCoin} onValueChange={setSelectedCoin} disabled={loading}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a coin" />
                        </SelectTrigger>
                        <SelectContent>
                          {coins.map((coin) => (
                            <SelectItem key={coin.id} value={coin.id}>
                              <div className="flex items-center gap-2">
                                <img
                                  src={coin.image || "/placeholder.svg"}
                                  alt={coin.name}
                                  className="h-5 w-5 rounded-full"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=20&width=20"
                                  }}
                                />
                                {coin.name} ({coin.symbol.toUpperCase()})
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {alertType === "price" && (
                      <>
                        <div className="space-y-2">
                          <Label htmlFor="condition">Condition</Label>
                          <Select value={condition} onValueChange={(value) => setCondition(value as "above" | "below")}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select condition" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="above">Price Above</SelectItem>
                              <SelectItem value="below">Price Below</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="threshold">Price Threshold ($)</Label>
                          <Input
                            id="threshold"
                            type="number"
                            placeholder="0.00"
                            value={threshold}
                            onChange={(e) => setThreshold(e.target.value)}
                          />
                        </div>
                      </>
                    )}

                    {alertType === "news" && (
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground">
                          You will receive alerts when important news about{" "}
                          {selectedCoin ? coins.find((c) => c.id === selectedCoin)?.name : "the selected coin"} is
                          published.
                        </p>
                      </div>
                    )}

                    {alertType === "trend" && (
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground">
                          You will receive alerts when{" "}
                          {selectedCoin ? coins.find((c) => c.id === selectedCoin)?.name : "the selected coin"} is
                          trending on social media platforms.
                        </p>
                      </div>
                    )}
                  </form>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleCreateAlert} className="w-full">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Alert
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Alert Settings</CardTitle>
                  <CardDescription>Configure how you receive alerts</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="push-notifications">Push Notifications</Label>
                        <p className="text-sm text-muted-foreground">Receive alerts on your device</p>
                      </div>
                      <Switch id="push-notifications" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="email-notifications">Email Notifications</Label>
                        <p className="text-sm text-muted-foreground">Receive alerts via email</p>
                      </div>
                      <Switch id="email-notifications" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="sound-notifications">Sound Alerts</Label>
                        <p className="text-sm text-muted-foreground">Play sound when alerts are triggered</p>
                      </div>
                      <Switch id="sound-notifications" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="do-not-disturb">Do Not Disturb</Label>
                        <p className="text-sm text-muted-foreground">Mute alerts during specific hours</p>
                      </div>
                      <Switch id="do-not-disturb" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Your Alerts</CardTitle>
                <CardDescription>Manage your active and triggered alerts</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-4">
                    {Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-4">
                            <Skeleton className="h-10 w-10 rounded-full" />
                            <div className="space-y-2">
                              <Skeleton className="h-4 w-40" />
                              <Skeleton className="h-4 w-20" />
                            </div>
                          </div>
                          <Skeleton className="h-8 w-20" />
                        </div>
                      ))}
                  </div>
                ) : alerts.length > 0 ? (
                  <div className="space-y-4">
                    {alerts.map((alert, index) => {
                      const coin = coins.find((c) => c.id === alert.coin)
                      return (
                        <motion.div
                          key={alert.id}
                          className={`flex items-center justify-between p-4 border rounded-lg ${
                            alert.triggered ? "bg-muted/50" : ""
                          }`}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2, delay: index * 0.05 }}
                        >
                          <div className="flex items-center gap-4">
                            <div
                              className={`flex items-center justify-center h-10 w-10 rounded-full ${
                                alert.triggered ? "bg-muted" : "bg-primary/10"
                              }`}
                            >
                              {alert.triggered ? <BellOff className="h-5 w-5" /> : <BellRing className="h-5 w-5" />}
                            </div>
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                {alertTypeIcon(alert.type)}
                                {alert.message}
                              </div>
                              <div className="text-sm text-muted-foreground flex items-center gap-2">
                                <span>Created: {formatDate(alert.created_at)}</span>
                                <Badge variant={alert.triggered ? "outline" : "default"}>
                                  {alert.triggered ? "Triggered" : "Active"}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteAlert(alert.id)}
                            className="text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </motion.div>
                      )
                    })}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <Bell className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium">No alerts yet</h3>
                    <p />
                    <h3 className="text-lg font-medium">No alerts yet</h3>
                    <p className="text-sm text-muted-foreground">
                      Create your first alert to get notified about price movements, news, or trends.
                    </p>
                    <Button
                      onClick={() => document.getElementById("create-alert")?.scrollIntoView({ behavior: "smooth" })}
                      className="mt-4"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Create Alert
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
