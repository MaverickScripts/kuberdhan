"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { motion } from "framer-motion"
import { ArrowRight, TrendingUp, Shield, Zap, Smartphone } from "lucide-react"

export function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <motion.h1
                    className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    Your Crypto. <span className="text-primary">Your Vibe.</span>
                  </motion.h1>
                  <motion.p
                    className="max-w-[600px] text-muted-foreground md:text-xl"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                  >
                    Kuberdhan is a cutting-edge cryptocurrency portfolio tracker designed for Gen Z. Track your assets,
                    simulate trades, and stay updated with the latest crypto trends.
                  </motion.p>
                </div>
                <motion.div
                  className="flex flex-col gap-2 min-[400px]:flex-row"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <Link href="/signup">
                    <Button size="lg" className="animated-gradient">
                      Get Started
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/login">
                    <Button size="lg" variant="outline">
                      Login
                    </Button>
                  </Link>
                </motion.div>
              </div>
              <motion.div
                className="flex items-center justify-center"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <div className="relative h-[350px] w-[350px] sm:h-[400px] sm:w-[400px] lg:h-[500px] lg:w-[500px]">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary opacity-20 blur-3xl rounded-full"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="glassmorphism rounded-xl p-4 w-full max-w-md">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-bold">Portfolio Overview</h3>
                          <TrendingUp className="text-green-500" />
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Total Value</span>
                            <span className="font-bold">$12,345.67</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">24h Change</span>
                            <span className="text-green-500">+5.23%</span>
                          </div>
                        </div>
                        <div className="h-32 bg-muted/50 rounded-lg flex items-center justify-center">
                          <span className="text-muted-foreground">Portfolio Chart</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Features</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Everything you need to manage your crypto portfolio in one place
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-4">
              <motion.div
                className="flex flex-col items-center space-y-2 rounded-lg p-4 glassmorphism hover-float"
                whileHover={{ y: -5 }}
              >
                <div className="rounded-full bg-primary/10 p-2">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Portfolio Tracking</h3>
                <p className="text-center text-muted-foreground">
                  Track your crypto holdings, total value, and ROI in real-time
                </p>
              </motion.div>
              <motion.div
                className="flex flex-col items-center space-y-2 rounded-lg p-4 glassmorphism hover-float"
                whileHover={{ y: -5 }}
              >
                <div className="rounded-full bg-primary/10 p-2">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Paper Trading</h3>
                <p className="text-center text-muted-foreground">
                  Simulate trades and test strategies without risking real money
                </p>
              </motion.div>
              <motion.div
                className="flex flex-col items-center space-y-2 rounded-lg p-4 glassmorphism hover-float"
                whileHover={{ y: -5 }}
              >
                <div className="rounded-full bg-primary/10 p-2">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">News & Alerts</h3>
                <p className="text-center text-muted-foreground">
                  Stay updated with the latest crypto news and price alerts
                </p>
              </motion.div>
              <motion.div
                className="flex flex-col items-center space-y-2 rounded-lg p-4 glassmorphism hover-float"
                whileHover={{ y: -5 }}
              >
                <div className="rounded-full bg-primary/10 p-2">
                  <Smartphone className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Mobile Friendly</h3>
                <p className="text-center text-muted-foreground">
                  Access your portfolio on any device with our responsive design
                </p>
              </motion.div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
