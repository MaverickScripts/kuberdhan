"use client"

import { useEffect, useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { getNews, type NewsItem } from "@/lib/api"
import { motion } from "framer-motion"
import {
  Search,
  Newspaper,
  TrendingUp,
  Twitter,
  MessageSquare,
  Share2,
  Bookmark,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export function NewsPage() {
  const [loading, setLoading] = useState(true)
  const [news, setNews] = useState<NewsItem[]>([])
  const [filteredNews, setFilteredNews] = useState<NewsItem[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const newsData = await getNews()
        setNews(newsData)
        setFilteredNews(newsData)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch news data. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredNews(news)
    } else {
      const filtered = news.filter(
        (item) =>
          item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.category.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setFilteredNews(filtered)
    }
  }, [searchQuery, news])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    }).format(date)
  }

  const sentimentColor = (category: string) => {
    switch (category.toLowerCase()) {
      case "bitcoin":
        return "text-orange-500"
      case "ethereum":
        return "text-purple-500"
      case "defi":
        return "text-blue-500"
      case "cardano":
        return "text-teal-500"
      case "dogecoin":
        return "text-yellow-500"
      default:
        return "text-gray-500"
    }
  }

  const sentimentIcon = (category: string) => {
    // This is just a simple example - in a real app you'd have actual sentiment analysis
    const randomSentiment = Math.random()
    if (randomSentiment > 0.6) {
      return <ArrowUpRight className="h-4 w-4 text-green-500" />
    } else if (randomSentiment < 0.4) {
      return <ArrowDownRight className="h-4 w-4 text-red-500" />
    } else {
      return <span className="h-4 w-4 text-yellow-500">•</span>
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 py-6">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6">
            <div className="flex flex-col gap-2">
              <h1 className="text-3xl font-bold tracking-tight">News & Trends</h1>
              <p className="text-muted-foreground">Stay updated with the latest crypto news and social sentiment</p>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex w-full max-w-sm items-center space-x-2">
                <Input
                  type="search"
                  placeholder="Search news..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
                <Button type="submit" size="icon" variant="ghost">
                  <Search className="h-4 w-4" />
                  <span className="sr-only">Search</span>
                </Button>
              </div>
            </div>

            <Tabs defaultValue="news" className="w-full">
              <TabsList className="grid w-full grid-cols-3 md:w-auto">
                <TabsTrigger value="news">
                  <Newspaper className="mr-2 h-4 w-4" />
                  News
                </TabsTrigger>
                <TabsTrigger value="social">
                  <Twitter className="mr-2 h-4 w-4" />
                  Social
                </TabsTrigger>
                <TabsTrigger value="trends">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Trends
                </TabsTrigger>
              </TabsList>

              <TabsContent value="news" className="space-y-4">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {loading
                    ? Array(6)
                        .fill(0)
                        .map((_, i) => (
                          <Card key={i} className="overflow-hidden">
                            <Skeleton className="h-48 w-full" />
                            <CardHeader>
                              <Skeleton className="h-4 w-1/2 mb-2" />
                              <Skeleton className="h-6 w-full" />
                            </CardHeader>
                            <CardContent>
                              <Skeleton className="h-20 w-full" />
                            </CardContent>
                            <CardFooter>
                              <Skeleton className="h-4 w-1/3" />
                            </CardFooter>
                          </Card>
                        ))
                    : filteredNews.map((item, index) => (
                        <motion.div
                          key={item.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                        >
                          <Card className="overflow-hidden h-full flex flex-col hover-float">
                            <img
                              src={item.image || "/placeholder.svg?height=200&width=400"}
                              alt={item.title}
                              className="h-48 w-full object-cover"
                              onError={(e) => {
                                ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=200&width=400"
                              }}
                            />
                            <CardHeader className="pb-2">
                              <div className="flex items-center justify-between">
                                <Badge variant="outline" className={sentimentColor(item.category)}>
                                  {item.category}
                                </Badge>
                                <div className="flex items-center gap-1">
                                  {sentimentIcon(item.category)}
                                  <span className="text-xs text-muted-foreground">{item.source}</span>
                                </div>
                              </div>
                              <CardTitle className="line-clamp-2 text-lg">{item.title}</CardTitle>
                            </CardHeader>
                            <CardContent className="flex-grow">
                              <p className="text-sm text-muted-foreground line-clamp-3">{item.description}</p>
                            </CardContent>
                            <CardFooter className="flex justify-between border-t pt-4">
                              <span className="text-xs text-muted-foreground">{formatDate(item.published_at)}</span>
                              <div className="flex gap-2">
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <Share2 className="h-4 w-4" />
                                  <span className="sr-only">Share</span>
                                </Button>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <Bookmark className="h-4 w-4" />
                                  <span className="sr-only">Save</span>
                                </Button>
                              </div>
                            </CardFooter>
                          </Card>
                        </motion.div>
                      ))}
                </div>
              </TabsContent>

              <TabsContent value="social" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Social Sentiment</CardTitle>
                    <CardDescription>Latest discussions from social media platforms</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {loading ? (
                        Array(5)
                          .fill(0)
                          .map((_, i) => (
                            <div key={i} className="flex gap-4">
                              <Skeleton className="h-10 w-10 rounded-full" />
                              <div className="flex-1 space-y-2">
                                <Skeleton className="h-4 w-1/4" />
                                <Skeleton className="h-16 w-full" />
                                <div className="flex gap-4">
                                  <Skeleton className="h-4 w-16" />
                                  <Skeleton className="h-4 w-16" />
                                </div>
                              </div>
                            </div>
                          ))
                      ) : (
                        <>
                          {[
                            {
                              id: "1",
                              user: "CryptoExpert",
                              avatar: "/placeholder.svg?height=40&width=40",
                              content:
                                "Just analyzed the latest Bitcoin on-chain data. Accumulation from long-term holders continues despite market volatility. Bullish signal? #BTC #CryptoAnalysis",
                              time: "2h ago",
                              likes: 245,
                              comments: 37,
                              sentiment: "bullish",
                            },
                            {
                              id: "2",
                              user: "ETHDeveloper",
                              avatar: "/placeholder.svg?height=40&width=40",
                              content:
                                "The Ethereum ecosystem is growing faster than ever. Layer 2 solutions are solving scalability issues while maintaining security. The future is bright for $ETH! #Ethereum #L2",
                              time: "4h ago",
                              likes: 189,
                              comments: 23,
                              sentiment: "bullish",
                            },
                            {
                              id: "3",
                              user: "CryptoSkeptic",
                              avatar: "/placeholder.svg?height=40&width=40",
                              content:
                                "Be careful with altcoins right now. Many projects have little utility and are purely speculative. DYOR and don't invest more than you can afford to lose. #CryptoWarning",
                              time: "6h ago",
                              likes: 132,
                              comments: 56,
                              sentiment: "bearish",
                            },
                            {
                              id: "4",
                              user: "BlockchainDev",
                              avatar: "/placeholder.svg?height=40&width=40",
                              content:
                                "Working on a new DeFi protocol that will revolutionize lending and borrowing. Stay tuned for the announcement next week! #DeFi #Crypto",
                              time: "12h ago",
                              likes: 312,
                              comments: 41,
                              sentiment: "neutral",
                            },
                            {
                              id: "5",
                              user: "NFTCollector",
                              avatar: "/placeholder.svg?height=40&width=40",
                              content:
                                "NFT market showing signs of recovery. Blue chip collections maintaining value while new innovative projects are gaining traction. The space is maturing. #NFTs #DigitalArt",
                              time: "1d ago",
                              likes: 276,
                              comments: 32,
                              sentiment: "bullish",
                            },
                          ].map((post, index) => (
                            <motion.div
                              key={post.id}
                              className="flex gap-4 p-4 rounded-lg hover:bg-muted/50"
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              transition={{ duration: 0.3, delay: index * 0.1 }}
                            >
                              <img
                                src={post.avatar || "/placeholder.svg"}
                                alt={post.user}
                                className="h-10 w-10 rounded-full"
                              />
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium">@{post.user}</span>
                                  <span className="text-xs text-muted-foreground">{post.time}</span>
                                  {post.sentiment === "bullish" && <ArrowUpRight className="h-4 w-4 text-green-500" />}
                                  {post.sentiment === "bearish" && <ArrowDownRight className="h-4 w-4 text-red-500" />}
                                  {post.sentiment === "neutral" && <span className="h-4 w-4 text-yellow-500">•</span>}
                                </div>
                                <p className="mt-1 text-sm">{post.content}</p>
                                <div className="mt-2 flex gap-4 text-sm text-muted-foreground">
                                  <div className="flex items-center gap-1">
                                    <MessageSquare className="h-4 w-4" />
                                    <span>{post.comments}</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Share2 className="h-4 w-4" />
                                    <span>{post.likes}</span>
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="trends" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Market Trends</CardTitle>
                    <CardDescription>Popular topics and sentiment analysis</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium mb-2">Trending Topics</h3>
                        <div className="flex flex-wrap gap-2">
                          {[
                            { name: "#Bitcoin", count: 24.5, sentiment: "bullish" },
                            { name: "#Ethereum", count: 18.3, sentiment: "bullish" },
                            { name: "#NFTs", count: 12.7, sentiment: "neutral" },
                            { name: "#DeFi", count: 10.2, sentiment: "bullish" },
                            { name: "#Regulation", count: 8.6, sentiment: "bearish" },
                            { name: "#Metaverse", count: 7.9, sentiment: "neutral" },
                            { name: "#Layer2", count: 6.4, sentiment: "bullish" },
                            { name: "#Mining", count: 5.8, sentiment: "neutral" },
                            { name: "#Altcoins", count: 5.2, sentiment: "bearish" },
                            { name: "#Staking", count: 4.7, sentiment: "bullish" },
                          ].map((topic) => (
                            <Badge
                              key={topic.name}
                              variant="outline"
                              className={`text-sm py-1 px-2 ${
                                topic.sentiment === "bullish"
                                  ? "border-green-500"
                                  : topic.sentiment === "bearish"
                                    ? "border-red-500"
                                    : "border-yellow-500"
                              }`}
                            >
                              {topic.name} ({topic.count}K)
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-medium mb-2">Sentiment Overview</h3>
                        <div className="grid grid-cols-3 gap-4">
                          <Card className="border-green-500/50">
                            <CardContent className="p-4">
                              <div className="flex flex-col items-center">
                                <ArrowUpRight className="h-8 w-8 text-green-500 mb-2" />
                                <h4 className="font-medium">Bullish</h4>
                                <p className="text-2xl font-bold">58%</p>
                                <p className="text-xs text-muted-foreground">+5% from yesterday</p>
                              </div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <div className="flex flex-col items-center">
                                <span className="h-8 w-8 text-yellow-500 mb-2 flex items-center justify-center text-2xl">
                                  •
                                </span>
                                <h4 className="font-medium">Neutral</h4>
                                <p className="text-2xl font-bold">27%</p>
                                <p className="text-xs text-muted-foreground">-2% from yesterday</p>
                              </div>
                            </CardContent>
                          </Card>
                          <Card className="border-red-500/50">
                            <CardContent className="p-4">
                              <div className="flex flex-col items-center">
                                <ArrowDownRight className="h-8 w-8 text-red-500 mb-2" />
                                <h4 className="font-medium">Bearish</h4>
                                <p className="text-2xl font-bold">15%</p>
                                <p className="text-xs text-muted-foreground">-3% from yesterday</p>
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-medium mb-2">Trending Coins by Social Volume</h3>
                        <div className="space-y-2">
                          {[
                            { name: "Bitcoin", symbol: "BTC", change: 12.5, sentiment: "bullish" },
                            { name: "Ethereum", symbol: "ETH", change: 8.3, sentiment: "bullish" },
                            { name: "Solana", symbol: "SOL", change: 15.7, sentiment: "bullish" },
                            { name: "Cardano", symbol: "ADA", change: -3.2, sentiment: "bearish" },
                            { name: "Dogecoin", symbol: "DOGE", change: 7.9, sentiment: "neutral" },
                          ].map((coin, index) => (
                            <div
                              key={coin.symbol}
                              className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50"
                            >
                              <div className="flex items-center gap-2">
                                <div className="font-medium">
                                  {index + 1}. {coin.name}
                                </div>
                                <Badge variant="outline">{coin.symbol}</Badge>
                              </div>
                              <div className="flex items-center gap-2">
                                <span
                                  className={coin.change > 0 ? "text-green-500" : coin.change < 0 ? "text-red-500" : ""}
                                >
                                  {coin.change > 0 ? "+" : ""}
                                  {coin.change}%
                                </span>
                                {coin.sentiment === "bullish" && <ArrowUpRight className="h-4 w-4 text-green-500" />}
                                {coin.sentiment === "bearish" && <ArrowDownRight className="h-4 w-4 text-red-500" />}
                                {coin.sentiment === "neutral" && <span className="h-4 w-4 text-yellow-500">•</span>}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
