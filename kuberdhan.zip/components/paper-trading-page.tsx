"use client"

import { useEffect, useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getCoins, getPaperTrades, type Coin, type PaperTrade } from "@/lib/api"
import { motion } from "framer-motion"
import { ArrowUpRight, ArrowDownRight, TrendingUp, DollarSign, Trophy, Clock } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts"

export function PaperTradingPage() {
  const [loading, setLoading] = useState(true)
  const [coins, setCoins] = useState<Coin[]>([])
  const [trades, setTrades] = useState<PaperTrade[]>([])
  const [selectedCoin, setSelectedCoin] = useState<string>("")
  const [tradeAmount, setTradeAmount] = useState<string>("")
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const [coinsData, tradesData] = await Promise.all([getCoins(), getPaperTrades()])

        setCoins(coinsData)
        setTrades(tradesData)

        if (coinsData.length > 0) {
          setSelectedCoin(coinsData[0].id)
        }
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch data. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`
  }

  const handleTrade = (type: "buy" | "sell") => {
    if (!selectedCoin || !tradeAmount || isNaN(Number.parseFloat(tradeAmount)) || Number.parseFloat(tradeAmount) <= 0) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Please enter a valid amount.",
      })
      return
    }

    const coin = coins.find((c) => c.id === selectedCoin)
    if (!coin) return

    const amount = Number.parseFloat(tradeAmount)
    const price = coin.current_price
    const total = amount * price

    const newTrade: PaperTrade = {
      id: `trade_${Math.random().toString(36).substr(2, 9)}`,
      coin: selectedCoin,
      type,
      amount,
      price,
      total,
      date: new Date().toISOString(),
      profit_loss: 0,
      profit_loss_percentage: 0,
    }

    setTrades([newTrade, ...trades])
    setTradeAmount("")

    toast({
      title: `${type === "buy" ? "Bought" : "Sold"} ${amount} ${coin.symbol.toUpperCase()}`,
      description: `Total: ${formatCurrency(total)}`,
    })
  }

  const totalProfitLoss = trades.reduce((acc, trade) => acc + (trade.profit_loss || 0), 0)
  const selectedCoinData = coins.find((c) => c.id === selectedCoin)

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 py-6">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6">
            <div className="flex flex-col gap-2">
              <h1 className="text-3xl font-bold tracking-tight">Paper Trading</h1>
              <p className="text-muted-foreground">Simulate cryptocurrency trades without risking real money</p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {loading ? (
                Array(4)
                  .fill(0)
                  .map((_, i) => (
                    <Card key={i}>
                      <CardHeader className="pb-2">
                        <Skeleton className="h-4 w-1/2" />
                        <Skeleton className="h-8 w-3/4" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-4 w-full" />
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <DollarSign className="mr-2 h-4 w-4" />
                            Paper Balance
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">{formatCurrency(100000 + totalProfitLoss)}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          {totalProfitLoss >= 0 ? (
                            <ArrowUpRight className="mr-2 h-4 w-4 text-green-500" />
                          ) : (
                            <ArrowDownRight className="mr-2 h-4 w-4 text-red-500" />
                          )}
                          <span className={totalProfitLoss >= 0 ? "text-green-500" : "text-red-500"}>
                            {formatCurrency(totalProfitLoss)} ({formatPercentage((totalProfitLoss / 100000) * 100)})
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <TrendingUp className="mr-2 h-4 w-4" />
                            Total Trades
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">{trades.length}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <span className="text-muted-foreground">
                            Buy: {trades.filter((t) => t.type === "buy").length} | Sell:{" "}
                            {trades.filter((t) => t.type === "sell").length}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.2 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <Trophy className="mr-2 h-4 w-4" />
                            Leaderboard Rank
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">#42</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <span className="text-muted-foreground">Top 10% of traders</span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.3 }}
                  >
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4" />
                            Trading Since
                          </div>
                        </CardDescription>
                        <CardTitle className="text-2xl">30 Days</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center">
                          <span className="text-muted-foreground">
                            Daily profit: {formatPercentage((totalProfitLoss / 100000 / 30) * 100)}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </>
              )}
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <Card className="md:col-span-1">
                <CardHeader>
                  <CardTitle>New Trade</CardTitle>
                  <CardDescription>Simulate buying or selling cryptocurrencies</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="coin">Select Coin</Label>
                      <Select value={selectedCoin} onValueChange={setSelectedCoin} disabled={loading}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a coin" />
                        </SelectTrigger>
                        <SelectContent>
                          {coins.map((coin) => (
                            <SelectItem key={coin.id} value={coin.id}>
                              <div className="flex items-center gap-2">
                                <img
                                  src={coin.image || "/placeholder.svg"}
                                  alt={coin.name}
                                  className="h-5 w-5 rounded-full"
                                  onError={(e) => {
                                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=20&width=20"
                                  }}
                                />
                                {coin.name} ({coin.symbol.toUpperCase()})
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {selectedCoinData && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Current Price:</span>
                        <span className="font-medium">{formatCurrency(selectedCoinData.current_price)}</span>
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount</Label>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="0.00"
                        value={tradeAmount}
                        onChange={(e) => setTradeAmount(e.target.value)}
                        disabled={loading}
                      />
                    </div>

                    {selectedCoinData &&
                      tradeAmount &&
                      !isNaN(Number.parseFloat(tradeAmount)) &&
                      Number.parseFloat(tradeAmount) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Total:</span>
                          <span className="font-medium">
                            {formatCurrency(selectedCoinData.current_price * Number.parseFloat(tradeAmount))}
                          </span>
                        </div>
                      )}
                  </form>
                </CardContent>
                <CardFooter className="flex gap-2">
                  <Button
                    className="w-full"
                    onClick={() => handleTrade("buy")}
                    disabled={
                      loading ||
                      !selectedCoin ||
                      !tradeAmount ||
                      isNaN(Number.parseFloat(tradeAmount)) ||
                      Number.parseFloat(tradeAmount) <= 0
                    }
                  >
                    Buy
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => handleTrade("sell")}
                    disabled={
                      loading ||
                      !selectedCoin ||
                      !tradeAmount ||
                      isNaN(Number.parseFloat(tradeAmount)) ||
                      Number.parseFloat(tradeAmount) <= 0
                    }
                  >
                    Sell
                  </Button>
                </CardFooter>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Price Chart</CardTitle>
                  <CardDescription>
                    {selectedCoinData
                      ? `${selectedCoinData.name} (${selectedCoinData.symbol.toUpperCase()}) price chart`
                      : "Select a coin to view its price chart"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <Skeleton className="h-[300px] w-full" />
                  ) : selectedCoinData ? (
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={[
                            { date: "Apr 24", price: selectedCoinData.current_price * 0.95 },
                            { date: "Apr 25", price: selectedCoinData.current_price * 0.97 },
                            { date: "Apr 26", price: selectedCoinData.current_price * 0.94 },
                            { date: "Apr 27", price: selectedCoinData.current_price * 0.96 },
                            { date: "Apr 28", price: selectedCoinData.current_price * 0.98 },
                            { date: "Apr 29", price: selectedCoinData.current_price * 0.99 },
                            { date: "Apr 30", price: selectedCoinData.current_price },
                          ]}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis domain={["auto", "auto"]} tickFormatter={(value) => `${value.toLocaleString()}`} />
                          <Tooltip formatter={(value) => [`${Number(value).toLocaleString()}`, "Price"]} />
                          <Line
                            type="monotone"
                            dataKey="price"
                            stroke="hsl(var(--primary))"
                            strokeWidth={2}
                            dot={{ r: 4 }}
                            activeDot={{ r: 8 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-[300px]">
                      <p className="text-muted-foreground">Select a coin to view its price chart</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="trades" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:w-auto">
                <TabsTrigger value="trades">Trade History</TabsTrigger>
                <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
              </TabsList>

              <TabsContent value="trades" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Trade History</CardTitle>
                    <CardDescription>Your paper trading history and performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <div className="grid grid-cols-6 gap-4 p-4 font-medium">
                        <div>Coin</div>
                        <div className="text-center">Type</div>
                        <div className="text-right">Amount</div>
                        <div className="text-right">Price</div>
                        <div className="text-right">Total</div>
                        <div className="text-right">P/L</div>
                      </div>
                      {loading ? (
                        <div className="divide-y">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <div key={i} className="grid grid-cols-6 gap-4 p-4">
                                <div className="flex items-center gap-2">
                                  <Skeleton className="h-8 w-8 rounded-full" />
                                  <Skeleton className="h-4 w-16" />
                                </div>
                                <div className="text-center self-center">
                                  <Skeleton className="h-6 w-12 mx-auto" />
                                </div>
                                <div className="text-right self-center">
                                  <Skeleton className="h-4 w-16 ml-auto" />
                                </div>
                                <div className="text-right self-center">
                                  <Skeleton className="h-4 w-20 ml-auto" />
                                </div>
                                <div className="text-right self-center">
                                  <Skeleton className="h-4 w-20 ml-auto" />
                                </div>
                                <div className="text-right self-center">
                                  <Skeleton className="h-4 w-16 ml-auto" />
                                </div>
                              </div>
                            ))}
                        </div>
                      ) : trades.length > 0 ? (
                        <div className="divide-y">
                          {trades.map((trade, index) => {
                            const coin = coins.find((c) => c.id === trade.coin)
                            return (
                              <motion.div
                                key={trade.id}
                                className="grid grid-cols-6 gap-4 p-4 hover:bg-muted/50"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.3, delay: index * 0.05 }}
                              >
                                <div className="flex items-center gap-2">
                                  {coin && (
                                    <img
                                      src={coin.image || "/placeholder.svg"}
                                      alt={coin.name}
                                      className="h-8 w-8 rounded-full"
                                      onError={(e) => {
                                        ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=32&width=32"
                                      }}
                                    />
                                  )}
                                  <span>{coin?.symbol.toUpperCase()}</span>
                                </div>
                                <div className="text-center self-center">
                                  <Badge variant={trade.type === "buy" ? "default" : "secondary"}>
                                    {trade.type.toUpperCase()}
                                  </Badge>
                                </div>
                                <div className="text-right self-center">{trade.amount}</div>
                                <div className="text-right self-center">{formatCurrency(trade.price)}</div>
                                <div className="text-right self-center">{formatCurrency(trade.total)}</div>
                                <div className="text-right self-center">
                                  <span className={(trade.profit_loss || 0) >= 0 ? "text-green-500" : "text-red-500"}>
                                    {formatPercentage(trade.profit_loss_percentage || 0)}
                                  </span>
                                </div>
                              </motion.div>
                            )
                          })}
                        </div>
                      ) : (
                        <div className="p-8 text-center">
                          <p className="text-muted-foreground">No trades yet. Start trading to see your history.</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="leaderboard" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Global Leaderboard</CardTitle>
                    <CardDescription>Top paper traders by performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <div className="grid grid-cols-4 gap-4 p-4 font-medium">
                        <div>Rank</div>
                        <div>Trader</div>
                        <div className="text-right">Portfolio Value</div>
                        <div className="text-right">Return</div>
                      </div>
                      <div className="divide-y">
                        {[
                          {
                            rank: 1,
                            name: "CryptoWhale",
                            avatar: "/placeholder.svg?height=32&width=32",
                            value: 287654.32,
                            return: 187.65,
                          },
                          {
                            rank: 2,
                            name: "DiamondHands",
                            avatar: "/placeholder.svg?height=32&width=32",
                            value: 243987.65,
                            return: 143.99,
                          },
                          {
                            rank: 3,
                            name: "MoonShot",
                            avatar: "/placeholder.svg?height=32&width=32",
                            value: 198765.43,
                            return: 98.77,
                          },
                          {
                            rank: 4,
                            name: "HODLer",
                            avatar: "/placeholder.svg?height=32&width=32",
                            value: 176543.21,
                            return: 76.54,
                          },
                          {
                            rank: 5,
                            name: "SatoshiFan",
                            avatar: "/placeholder.svg?height=32&width=32",
                            value: 154321.98,
                            return: 54.32,
                          },
                          {
                            rank: 42,
                            name: "You",
                            avatar: "/placeholder.svg?height=32&width=32",
                            value: 100000 + totalProfitLoss,
                            return: (totalProfitLoss / 100000) * 100,
                            highlight: true,
                          },
                        ].map((trader, index) => (
                          <motion.div
                            key={index}
                            className={`grid grid-cols-4 gap-4 p-4 ${trader.highlight ? "bg-primary/10" : "hover:bg-muted/50"}`}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: index * 0.05 }}
                          >
                            <div className="self-center font-medium">#{trader.rank}</div>
                            <div className="flex items-center gap-2">
                              <img
                                src={trader.avatar || "/placeholder.svg"}
                                alt={trader.name}
                                className="h-8 w-8 rounded-full"
                              />
                              <span className={trader.highlight ? "font-bold" : ""}>{trader.name}</span>
                            </div>
                            <div className="text-right self-center">{formatCurrency(trader.value)}</div>
                            <div className="text-right self-center">
                              <span className={trader.return >= 0 ? "text-green-500" : "text-red-500"}>
                                {formatPercentage(trader.return)}
                              </span>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
