import { MarketPage } from "@/components/market-page"

export default function Market() {
  return <MarketPage />
}
