import { SignupPage } from "@/components/signup-page"

export default function Signup() {
  return <SignupPage />
}
