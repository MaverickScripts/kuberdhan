import { NewsPage } from "@/components/news-page"

export default function News() {
  return <NewsPage />
}
