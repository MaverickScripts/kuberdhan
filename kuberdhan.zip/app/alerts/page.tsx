import { AlertsPage } from "@/components/alerts-page"

export default function Alerts() {
  return <AlertsPage />
}
