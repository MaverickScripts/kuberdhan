import { DashboardPage } from "@/components/dashboard-page"

export default function Dashboard() {
  return <DashboardPage />
}
