import { AchievementsPage } from "@/components/achievements-page"

export default function Achievements() {
  return <AchievementsPage />
}
