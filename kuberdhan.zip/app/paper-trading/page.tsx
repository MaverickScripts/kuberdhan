import { PaperTradingPage } from "@/components/paper-trading-page"

export default function PaperTrading() {
  return <PaperTradingPage />
}
