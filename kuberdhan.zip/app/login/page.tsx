import { LoginPage } from "@/components/login-page"

export default function Login() {
  return <LoginPage />
}
