// Crypto data types
export interface Coin {
  id: string
  symbol: string
  name: string
  image: string
  current_price: number
  market_cap: number
  market_cap_rank: number
  fully_diluted_valuation: number | null
  total_volume: number
  high_24h: number
  low_24h: number
  price_change_24h: number
  price_change_percentage_24h: number
  market_cap_change_24h: number
  market_cap_change_percentage_24h: number
  circulating_supply: number
  total_supply: number | null
  max_supply: number | null
  ath: number
  ath_change_percentage: number
  ath_date: string
  atl: number
  atl_change_percentage: number
  atl_date: string
  last_updated: string
  sparkline_in_7d?: {
    price: number[]
  }
  price_change_percentage_1h_in_currency?: number
  price_change_percentage_24h_in_currency?: number
  price_change_percentage_7d_in_currency?: number
}

export interface NewsItem {
  id: string
  title: string
  description: string
  url: string
  source: string
  image: string
  category: string
  published_at: string
}

export interface Alert {
  id: string
  type: "price" | "news" | "trend"
  coin?: string
  condition?: string
  threshold?: number
  message: string
  created_at: string
  triggered?: boolean
}

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  unlocked: boolean
  progress?: number
  max_progress?: number
  unlocked_at?: string
}

export interface PaperTrade {
  id: string
  coin: string
  type: "buy" | "sell"
  amount: number
  price: number
  total: number
  date: string
  profit_loss?: number
  profit_loss_percentage?: number
}

// Mock data functions
export async function getCoins(): Promise<Coin[]> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [
    {
      id: "bitcoin",
      symbol: "btc",
      name: "Bitcoin",
      image: "https://assets.coingecko.com/coins/images/1/large/bitcoin.png",
      current_price: 61245.32,
      market_cap: 1203456789012,
      market_cap_rank: 1,
      fully_diluted_valuation: 1285000000000,
      total_volume: 32456789012,
      high_24h: 62345.67,
      low_24h: 60123.45,
      price_change_24h: 1122.87,
      price_change_percentage_24h: 1.87,
      market_cap_change_24h: 21345678901,
      market_cap_change_percentage_24h: 1.8,
      circulating_supply: 19456789,
      total_supply: 21000000,
      max_supply: 21000000,
      ath: 69000,
      ath_change_percentage: -11.24,
      ath_date: "2021-11-10T14:24:11.849Z",
      atl: 67.81,
      atl_change_percentage: 90235.07,
      atl_date: "2013-07-06T00:00:00.000Z",
      last_updated: "2023-04-30T12:30:00.000Z",
      sparkline_in_7d: {
        price: [60123, 61234, 62345, 61234, 60123, 61234, 61245],
      },
      price_change_percentage_1h_in_currency: 0.12,
      price_change_percentage_24h_in_currency: 1.87,
      price_change_percentage_7d_in_currency: 3.45,
    },
    {
      id: "ethereum",
      symbol: "eth",
      name: "Ethereum",
      image: "https://assets.coingecko.com/coins/images/279/large/ethereum.png",
      current_price: 3245.67,
      market_cap: 389012345678,
      market_cap_rank: 2,
      fully_diluted_valuation: 389012345678,
      total_volume: 12345678901,
      high_24h: 3345.67,
      low_24h: 3145.67,
      price_change_24h: 100,
      price_change_percentage_24h: 3.18,
      market_cap_change_24h: 12345678901,
      market_cap_change_percentage_24h: 3.28,
      circulating_supply: 120123456,
      total_supply: null,
      max_supply: null,
      ath: 4878.26,
      ath_change_percentage: -33.47,
      ath_date: "2021-11-10T14:24:19.604Z",
      atl: 0.432979,
      atl_change_percentage: 749551.24,
      atl_date: "2015-10-20T00:00:00.000Z",
      last_updated: "2023-04-30T12:30:00.000Z",
      sparkline_in_7d: {
        price: [3145, 3245, 3345, 3245, 3145, 3245, 3245],
      },
      price_change_percentage_1h_in_currency: 0.23,
      price_change_percentage_24h_in_currency: 3.18,
      price_change_percentage_7d_in_currency: 5.67,
    },
    {
      id: "solana",
      symbol: "sol",
      name: "Solana",
      image: "https://assets.coingecko.com/coins/images/4128/large/solana.png",
      current_price: 145.67,
      market_cap: 62345678901,
      market_cap_rank: 5,
      fully_diluted_valuation: 78901234567,
      total_volume: 2345678901,
      high_24h: 150.67,
      low_24h: 140.67,
      price_change_24h: 5,
      price_change_percentage_24h: 3.55,
      market_cap_change_24h: 2345678901,
      market_cap_change_percentage_24h: 3.91,
      circulating_supply: 428123456,
      total_supply: 534123456,
      max_supply: null,
      ath: 259.96,
      ath_change_percentage: -44.35,
      ath_date: "2021-11-06T21:54:35.825Z",
      atl: 0.5,
      atl_change_percentage: 29034.0,
      atl_date: "2020-05-11T19:35:23.449Z",
      last_updated: "2023-04-30T12:30:00.000Z",
      sparkline_in_7d: {
        price: [140, 145, 150, 145, 140, 145, 145],
      },
      price_change_percentage_1h_in_currency: 0.34,
      price_change_percentage_24h_in_currency: 3.55,
      price_change_percentage_7d_in_currency: 7.89,
    },
    {
      id: "cardano",
      symbol: "ada",
      name: "Cardano",
      image: "https://assets.coingecko.com/coins/images/975/large/cardano.png",
      current_price: 0.45,
      market_cap: 15901234567,
      market_cap_rank: 8,
      fully_diluted_valuation: 20123456789,
      total_volume: 567890123,
      high_24h: 0.47,
      low_24h: 0.44,
      price_change_24h: 0.01,
      price_change_percentage_24h: 2.27,
      market_cap_change_24h: 345678901,
      market_cap_change_percentage_24h: 2.22,
      circulating_supply: 35345678901,
      total_supply: 45000000000,
      max_supply: 45000000000,
      ath: 3.09,
      ath_change_percentage: -85.44,
      ath_date: "2021-09-02T06:00:10.474Z",
      atl: 0.01925,
      atl_change_percentage: 2237.66,
      atl_date: "2020-03-13T02:22:55.044Z",
      last_updated: "2023-04-30T12:30:00.000Z",
      sparkline_in_7d: {
        price: [0.44, 0.45, 0.47, 0.45, 0.44, 0.45, 0.45],
      },
      price_change_percentage_1h_in_currency: 0.12,
      price_change_percentage_24h_in_currency: 2.27,
      price_change_percentage_7d_in_currency: 4.56,
    },
    {
      id: "dogecoin",
      symbol: "doge",
      name: "Dogecoin",
      image: "https://assets.coingecko.com/coins/images/5/large/dogecoin.png",
      current_price: 0.15,
      market_cap: 21345678901,
      market_cap_rank: 7,
      fully_diluted_valuation: null,
      total_volume: 1234567890,
      high_24h: 0.16,
      low_24h: 0.14,
      price_change_24h: 0.01,
      price_change_percentage_24h: 7.14,
      market_cap_change_24h: 1234567890,
      market_cap_change_percentage_24h: 6.14,
      circulating_supply: 142345678901,
      total_supply: null,
      max_supply: null,
      ath: 0.731578,
      ath_change_percentage: -79.5,
      ath_date: "2021-05-08T05:08:23.458Z",
      atl: 0.0000869,
      atl_change_percentage: 172493.36,
      atl_date: "2015-05-06T00:00:00.000Z",
      last_updated: "2023-04-30T12:30:00.000Z",
      sparkline_in_7d: {
        price: [0.14, 0.15, 0.16, 0.15, 0.14, 0.15, 0.15],
      },
      price_change_percentage_1h_in_currency: 0.45,
      price_change_percentage_24h_in_currency: 7.14,
      price_change_percentage_7d_in_currency: 9.87,
    },
  ]
}

export async function getPortfolio(): Promise<{
  coins: { coin: Coin; amount: number; value: number }[]
  total_value: number
  daily_change: number
  daily_change_percentage: number
  total_profit_loss: number
  total_profit_loss_percentage: number
}> {
  const coins = await getCoins()

  const portfolio = {
    coins: [
      {
        coin: coins[0],
        amount: 0.5,
        value: coins[0].current_price * 0.5,
      },
      {
        coin: coins[1],
        amount: 2.5,
        value: coins[1].current_price * 2.5,
      },
      {
        coin: coins[2],
        amount: 10,
        value: coins[2].current_price * 10,
      },
    ],
    total_value: 0,
    daily_change: 0,
    daily_change_percentage: 0,
    total_profit_loss: 5678.9,
    total_profit_loss_percentage: 12.34,
  }

  portfolio.total_value = portfolio.coins.reduce((acc, coin) => acc + coin.value, 0)
  portfolio.daily_change = portfolio.coins.reduce((acc, coin) => acc + coin.coin.price_change_24h * coin.amount, 0)
  portfolio.daily_change_percentage = (portfolio.daily_change / (portfolio.total_value - portfolio.daily_change)) * 100

  return portfolio
}

export async function getNews(): Promise<NewsItem[]> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [
    {
      id: "1",
      title: "Bitcoin Surges Past $60,000 as Institutional Adoption Grows",
      description:
        "Bitcoin has surged past $60,000 as institutional adoption continues to grow, with major companies adding the cryptocurrency to their balance sheets.",
      url: "#",
      source: "CryptoNews",
      image: "/placeholder.svg?height=200&width=400",
      category: "Bitcoin",
      published_at: "2023-04-30T10:30:00.000Z",
    },
    {
      id: "2",
      title: "Ethereum 2.0 Upgrade on Track for Q3 2023",
      description:
        "The Ethereum 2.0 upgrade is on track for Q3 2023, with developers making significant progress on the transition to proof-of-stake.",
      url: "#",
      source: "ETH Daily",
      image: "/placeholder.svg?height=200&width=400",
      category: "Ethereum",
      published_at: "2023-04-29T14:45:00.000Z",
    },
    {
      id: "3",
      title: "Solana Ecosystem Expands with New DeFi Projects",
      description:
        "The Solana ecosystem is expanding rapidly with new DeFi projects launching on the high-performance blockchain.",
      url: "#",
      source: "DeFi Pulse",
      image: "/placeholder.svg?height=200&width=400",
      category: "DeFi",
      published_at: "2023-04-28T09:15:00.000Z",
    },
    {
      id: "4",
      title: "Cardano Smart Contracts See Increased Adoption",
      description:
        "Cardano smart contracts are seeing increased adoption as developers migrate from other platforms due to lower fees and improved scalability.",
      url: "#",
      source: "Crypto Insider",
      image: "/placeholder.svg?height=200&width=400",
      category: "Cardano",
      published_at: "2023-04-27T16:20:00.000Z",
    },
    {
      id: "5",
      title: "Dogecoin Community Funds New Development Initiatives",
      description:
        "The Dogecoin community has funded new development initiatives to improve the cryptocurrency's utility and adoption.",
      url: "#",
      source: "Meme Coin News",
      image: "/placeholder.svg?height=200&width=400",
      category: "Dogecoin",
      published_at: "2023-04-26T11:10:00.000Z",
    },
  ]
}

export async function getAlerts(): Promise<Alert[]> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [
    {
      id: "1",
      type: "price",
      coin: "bitcoin",
      condition: "above",
      threshold: 65000,
      message: "Bitcoin price is above $65,000",
      created_at: "2023-04-25T10:30:00.000Z",
      triggered: false,
    },
    {
      id: "2",
      type: "price",
      coin: "ethereum",
      condition: "below",
      threshold: 3000,
      message: "Ethereum price is below $3,000",
      created_at: "2023-04-24T14:45:00.000Z",
      triggered: true,
    },
    {
      id: "3",
      type: "news",
      message: "Breaking news about Solana ecosystem",
      created_at: "2023-04-23T09:15:00.000Z",
      triggered: true,
    },
    {
      id: "4",
      type: "trend",
      coin: "cardano",
      message: "Cardano is trending on social media",
      created_at: "2023-04-22T16:20:00.000Z",
      triggered: false,
    },
    {
      id: "5",
      type: "price",
      coin: "dogecoin",
      condition: "above",
      threshold: 0.2,
      message: "Dogecoin price is above $0.2",
      created_at: "2023-04-21T11:10:00.000Z",
      triggered: false,
    },
  ]
}

export async function getAchievements(): Promise<Achievement[]> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [
    {
      id: "1",
      title: "First Trade",
      description: "Complete your first paper trade",
      icon: "🚀",
      unlocked: true,
      unlocked_at: "2023-04-20T10:30:00.000Z",
    },
    {
      id: "2",
      title: "Diamond Hands",
      description: "Hold a cryptocurrency for 30 days",
      icon: "💎",
      unlocked: true,
      unlocked_at: "2023-04-15T14:45:00.000Z",
    },
    {
      id: "3",
      title: "Diversification Master",
      description: "Own 5 different cryptocurrencies",
      icon: "🌈",
      unlocked: false,
      progress: 3,
      max_progress: 5,
    },
    {
      id: "4",
      title: "Profit Hunter",
      description: "Make 10 profitable trades",
      icon: "🎯",
      unlocked: false,
      progress: 4,
      max_progress: 10,
    },
    {
      id: "5",
      title: "Crypto Whale",
      description: "Have a portfolio worth over $100,000",
      icon: "🐋",
      unlocked: false,
      progress: 42345.67,
      max_progress: 100000,
    },
  ]
}

export async function getPaperTrades(): Promise<PaperTrade[]> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [
    {
      id: "1",
      coin: "bitcoin",
      type: "buy",
      amount: 0.5,
      price: 58000,
      total: 29000,
      date: "2023-04-15T10:30:00.000Z",
      profit_loss: 1622.66,
      profit_loss_percentage: 5.6,
    },
    {
      id: "2",
      coin: "ethereum",
      type: "buy",
      amount: 2.5,
      price: 3000,
      total: 7500,
      date: "2023-04-10T14:45:00.000Z",
      profit_loss: 614.18,
      profit_loss_percentage: 8.19,
    },
    {
      id: "3",
      coin: "solana",
      type: "buy",
      amount: 10,
      price: 130,
      total: 1300,
      date: "2023-04-05T09:15:00.000Z",
      profit_loss: 156.7,
      profit_loss_percentage: 12.05,
    },
    {
      id: "4",
      coin: "cardano",
      type: "sell",
      amount: 1000,
      price: 0.5,
      total: 500,
      date: "2023-03-25T16:20:00.000Z",
      profit_loss: -50,
      profit_loss_percentage: -10,
    },
    {
      id: "5",
      coin: "dogecoin",
      type: "buy",
      amount: 1000,
      price: 0.12,
      total: 120,
      date: "2023-03-20T11:10:00.000Z",
      profit_loss: 30,
      profit_loss_percentage: 25,
    },
  ]
}
